package com.andryshaoff.rxnative;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Логика матча (бой насмерть с ботами): движение, стрельба, урон, возрождение, ИИ ботов. Без графики — её рисует GameRenderer. */
final class Game {
    interface Events { void shot(boolean me, float dist); void hitMarker(boolean head); void hurt(); void kill(String killer, String victim, boolean head); }

    static final String[] NAMES = {"Kozak_UA", "PolarBear", "Wasabi", "Nomad", "Raptor", "Vortex_7", "ViperX", "Tractor"};
    static final float EYE = 1.62f, EYE_C = 1.2f, RADIUS = 0.36f, SPEED = 5.4f, WALK = 2.7f, GRAV = 18f, JUMP = 5.6f;

    static final class Actor {
        final String name; final boolean bot; final float[] color;
        float x, y, z, vy, yaw, pitch, hp = 100, respawnT, fireCd, reloadT, recoil, spread, walkPhase, crouchK, hitFlash, deadT;
        int mag = 30, reserve = 90, kills, deaths; boolean alive = true, onGround = true;
        // бот
        int[] path; int pathI; float thinkT, repathT, reactT, strafeT, strafeDir = 1, aimErr; Actor target; float lastSeenX, lastSeenZ, lastSeenT = -99;
        Actor(String n, boolean bot, float[] col) { name = n; this.bot = bot; color = col; }
        float eye() { return y + (EYE - (EYE - EYE_C) * crouchK); }
        float height() { return 1.8f - 0.5f * crouchK; }
    }

    final World w; final Random rnd = new Random(); Events ev;
    final List<Actor> actors = new ArrayList<>(); final Actor me;
    float time;
    // для HUD
    volatile float hudHitT = -9, hudHurtT = -9; volatile String lastKill = ""; volatile float lastKillT = -9;

    Game(World w, Events ev) {
        this.w = w; this.ev = ev;
        me = new Actor("ТЫ", false, new float[]{0.25f, 0.33f, 0.62f}); actors.add(me);
        float[][] cols = {{0.54f, 0.23f, 0.16f}, {0.2f, 0.26f, 0.5f}, {0.36f, 0.4f, 0.24f}, {0.5f, 0.42f, 0.3f}, {0.3f, 0.3f, 0.34f}, {0.55f, 0.3f, 0.2f}, {0.18f, 0.35f, 0.4f}};
        for (int i = 0; i < 7; i++) actors.add(new Actor(NAMES[i], true, cols[i]));
        for (Actor a : actors) spawn(a);
    }

    void spawn(Actor a) {
        int[] best = null; float bestD = -1;
        for (int k = 0; k < 12; k++) { // точка подальше от остальных
            int[] c = w.spawns.isEmpty() ? w.randomWalkable(rnd) : (k < 6 ? w.spawns.get(rnd.nextInt(w.spawns.size())) : w.randomWalkable(rnd));
            float cx = (c[0] + 0.5f) * World.CELL, cz = (c[1] + 0.5f) * World.CELL, md = 999;
            for (Actor o : actors) if (o != a && o.alive) md = Math.min(md, (o.x - cx) * (o.x - cx) + (o.z - cz) * (o.z - cz));
            if (md > bestD) { bestD = md; best = c; }
        }
        a.x = (best[0] + 0.5f) * World.CELL; a.z = (best[1] + 0.5f) * World.CELL; a.y = w.groundAt(a.x, a.z, RADIUS, 0); a.vy = 0;
        a.hp = 100; a.alive = true; a.mag = 30; a.reserve = 90; a.reloadT = 0; a.path = null; a.target = null; a.yaw = rnd.nextFloat() * 6.283f; a.pitch = 0; a.deadT = 0;
    }

    private final float[] look = new float[2];

    void update(float dt, float sens) {
        time += dt;
        // ввод игрока
        if (me.alive) {
            Input.takeLook(look);
            me.yaw -= look[0] * 0.0042f * sens; me.pitch = clamp(me.pitch - look[1] * 0.0042f * sens, -1.45f, 1.45f);
            me.crouchK += ((Input.crouch ? 1 : 0) - me.crouchK) * Math.min(1, dt * 12);
            float mx = Input.moveX, my = Input.moveY, L = (float) Math.sqrt(mx * mx + my * my);
            float sp = (Input.walk || me.crouchK > 0.5f || (L > 0 && L < 0.55f)) ? WALK : SPEED;
            if (L > 1) { mx /= L; my /= L; }
            float fwd = -my, str = mx, s = (float) Math.sin(me.yaw), c = (float) Math.cos(me.yaw);
            float vx = (-s * fwd + c * str) * sp, vz = (-c * fwd - s * str) * sp;
            if (Input.jumpQ) { Input.jumpQ = false; if (me.onGround) { me.vy = JUMP; me.onGround = false; } }
            physics(me, vx, vz, dt);
            me.spread = L > 0.2f ? 0.035f : 0.006f; if (!me.onGround) me.spread = 0.08f; if (me.crouchK > 0.5f) me.spread *= 0.6f;
            if (Input.reloadQ) { Input.reloadQ = false; startReload(me); }
            weapon(me, Input.fire, dt);
        } else { Input.takeLook(look); }

        for (Actor a : actors) {
            if (!a.alive) { a.deadT += dt; a.respawnT -= dt; if (a.respawnT <= 0) spawn(a); continue; }
            a.hitFlash = Math.max(0, a.hitFlash - dt);
            if (a.bot) bot(a, dt);
        }
    }

    void physics(Actor a, float vx, float vz, float dt) {
        a.vy -= GRAV * dt;
        float nx = a.x + vx * dt; if (!w.blocked(nx, a.z, RADIUS, a.y)) a.x = nx;
        float nz = a.z + vz * dt; if (!w.blocked(a.x, nz, RADIUS, a.y)) a.z = nz;
        float gy = w.groundAt(a.x, a.z, RADIUS, a.y);
        a.y += a.vy * dt;
        if (a.y <= gy) { a.y = gy; a.vy = 0; a.onGround = true; } else if (a.y > gy + 0.05f) a.onGround = false;
        float sp = (float) Math.sqrt(vx * vx + vz * vz); a.walkPhase += sp * dt * 1.9f;
    }

    void startReload(Actor a) { if (a.reloadT <= 0 && a.mag < 30 && a.reserve > 0) a.reloadT = 2.3f; }

    /** Автомат: 600 выстр/мин, 36 урона в тело, 110 в голову, разброс и отдача. */
    void weapon(Actor a, boolean trigger, float dt) {
        a.fireCd -= dt; a.recoil = Math.max(0, a.recoil - dt * (trigger ? 0.6f : 3.5f));
        if (a.reloadT > 0) { a.reloadT -= dt; if (a.reloadT <= 0) { int n = Math.min(30 - a.mag, a.reserve); a.mag += n; a.reserve -= n; } return; }
        if (a.mag <= 0) { startReload(a); return; }
        if (!trigger || a.fireCd > 0) return;
        a.fireCd = 0.1f; a.mag--;
        float spr = a.spread + a.recoil * 0.05f + (a.bot ? a.aimErr : 0);
        float yaw = a.yaw + (float) rnd.nextGaussian() * spr, pitch = a.pitch + a.recoil * 0.08f + (float) rnd.nextGaussian() * spr * 0.6f;
        if (a == me) { me.pitch = clamp(me.pitch + 0.012f, -1.45f, 1.45f); }
        a.recoil = Math.min(1.4f, a.recoil + 0.16f);
        float cp = (float) Math.cos(pitch), dx = -(float) Math.sin(yaw) * cp, dy = (float) Math.sin(pitch), dz = -(float) Math.cos(yaw) * cp;
        float ox = a.x, oy = a.eye(), oz = a.z;
        float wall = w.ray(ox, oy, oz, dx, dy, dz, 120f);
        Actor hit = null; float ht = wall; boolean head = false;
        for (Actor t : actors) {
            if (t == a || !t.alive) continue;
            float tt = rayCyl(ox, oz, dx, dz, t.x, t.z, 0.38f); if (tt < 0 || tt >= ht) continue;
            float yy = oy + dy * tt; if (yy < t.y || yy > t.y + t.height()) continue;
            hit = t; ht = tt; head = yy > t.y + t.height() - 0.3f;
        }
        lastTracer[0] = ox; lastTracer[1] = oy - 0.15f; lastTracer[2] = oz; lastTracer[3] = ox + dx * ht; lastTracer[4] = oy + dy * ht; lastTracer[5] = oz + dz * ht; tracerT = 0.05f; tracerMe = a == me;
        float dist = (float) Math.sqrt((a.x - me.x) * (a.x - me.x) + (a.z - me.z) * (a.z - me.z));
        if (ev != null) ev.shot(a == me, dist);
        if (hit != null) damage(a, hit, head ? 110 : (oy + dy * ht < hit.y + 0.8f ? 27 : 36), head);
    }
    final float[] lastTracer = new float[6]; float tracerT; boolean tracerMe;

    void damage(Actor from, Actor to, float dmg, boolean head) {
        to.hp -= dmg; to.hitFlash = 0.12f;
        if (to.bot && to.target == null) { to.target = from; to.reactT = 0.15f; }
        if (from == me && ev != null) { ev.hitMarker(head); hudHitT = time; }
        if (to == me) { hudHurtT = time; if (ev != null) ev.hurt(); }
        if (to.hp <= 0) {
            to.alive = false; to.hp = 0; to.deaths++; from.kills++; to.respawnT = 3f; to.deadT = 0;
            lastKill = from.name + (head ? "  ⌖  " : "  ▸  ") + to.name; lastKillT = time;
            if (ev != null) ev.kill(from.name, to.name, head);
        }
    }

    static float rayCyl(float ox, float oz, float dx, float dz, float cx, float cz, float r) {
        float hl2 = dx * dx + dz * dz; if (hl2 < 1e-8f) return -1;
        float fx = ox - cx, fz = oz - cz, b = fx * dx + fz * dz, c = fx * fx + fz * fz - r * r, disc = b * b - hl2 * c;
        if (disc < 0) return -1; float t = (-b - (float) Math.sqrt(disc)) / hl2; return t < 0 ? -1 : t;
    }

    /* ---------------- боты ---------------- */
    void bot(Actor a, float dt) {
        a.thinkT -= dt; a.repathT -= dt; a.reactT -= dt; a.strafeT -= dt;
        if (a.thinkT <= 0) { a.thinkT = 0.12f + rnd.nextFloat() * 0.06f; botVision(a); }
        float vx = 0, vz = 0; boolean shoot = false;
        if (a.target != null && a.target.alive && time - a.lastSeenT < 0.4f) {
            Actor t = a.target;
            float dx = t.x - a.x, dz = t.z - a.z, dy = (t.y + t.height() * 0.78f) - a.eye(), hd = (float) Math.sqrt(dx * dx + dz * dz);
            float wantYaw = (float) Math.atan2(-dx, -dz), wantPitch = (float) Math.atan2(dy, hd);
            float k = Math.min(1, dt * 7);
            a.yaw += wrap(wantYaw - a.yaw) * k; a.pitch += (wantPitch - a.pitch) * k;
            float err = Math.abs(wrap(wantYaw - a.yaw)) + Math.abs(wantPitch - a.pitch);
            a.aimErr = 0.02f + Math.min(0.05f, hd * 0.0012f);
            shoot = a.reactT <= 0 && err < 0.08f;
            if (a.strafeT <= 0) { a.strafeT = 0.5f + rnd.nextFloat() * 0.9f; a.strafeDir = rnd.nextBoolean() ? 1 : -1; }
            float s = (float) Math.sin(a.yaw), c = (float) Math.cos(a.yaw), sp = hd > 14 ? 3.2f : 2.2f;
            vx = c * a.strafeDir * sp; vz = -s * a.strafeDir * sp;
            if (hd > 22) { vx += -s * 2.5f; vz += -c * 2.5f; }
            a.path = null;
        } else {
            if (a.target != null && time - a.lastSeenT < 6) { // идём туда, где видели цель
                if (a.path == null || a.repathT <= 0) { a.repathT = 1.5f; int tx = World.cellOf(a.lastSeenX), tz = World.cellOf(a.lastSeenZ); if (!w.walkable(tx, tz)) { outer: for (int r = 1; r <= 2; r++) for (int ddz = -r; ddz <= r; ddz++) for (int ddx = -r; ddx <= r; ddx++) if (w.walkable(tx + ddx, tz + ddz)) { tx += ddx; tz += ddz; break outer; } } a.path = w.path(World.cellOf(a.x), World.cellOf(a.z), tx, tz); a.pathI = 0; }
            } else if (a.path == null || a.pathI >= a.path.length || a.repathT <= 0) {
                a.target = null; a.repathT = 6f; int[] c = w.randomWalkable(rnd); a.path = w.path(World.cellOf(a.x), World.cellOf(a.z), c[0], c[1]); a.pathI = 0;
            }
            if (a.path != null && a.pathI < a.path.length) {
                int n = a.path[a.pathI]; float px = (n % w.W + 0.5f) * World.CELL, pz = (n / w.W + 0.5f) * World.CELL;
                float dx = px - a.x, dz = pz - a.z, d = (float) Math.sqrt(dx * dx + dz * dz);
                if (d < 0.6f) a.pathI++; else { vx = dx / d * SPEED * 0.85f; vz = dz / d * SPEED * 0.85f; float wy = (float) Math.atan2(-dx, -dz); a.yaw += wrap(wy - a.yaw) * Math.min(1, dt * 6); a.pitch *= 0.9f; }
            }
        }
        physics(a, vx, vz, dt);
        a.spread = (vx != 0 || vz != 0) ? 0.03f : 0.01f;
        weapon(a, shoot, dt);
    }

    void botVision(Actor a) {
        Actor best = null; float bd = 1e9f;
        float fx = -(float) Math.sin(a.yaw), fz = -(float) Math.cos(a.yaw);
        for (Actor t : actors) {
            if (t == a || !t.alive) continue;
            float dx = t.x - a.x, dz = t.z - a.z, d2 = dx * dx + dz * dz; if (d2 > 70 * 70) continue;
            float d = (float) Math.sqrt(d2); boolean inFov = (dx * fx + dz * fz) / Math.max(0.01f, d) > 0.2f || t == a.target;
            if (!inFov) continue;
            if (!w.los(a.x, a.eye(), a.z, t.x, t.y + t.height() * 0.8f, t.z)) continue;
            if (d2 < bd) { bd = d2; best = t; }
        }
        if (best != null) {
            if (best != a.target) a.reactT = 0.28f + rnd.nextFloat() * 0.25f;
            a.target = best; a.lastSeenX = best.x; a.lastSeenZ = best.z; a.lastSeenT = time;
        }
    }

    static float wrap(float a) { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; }
    static float clamp(float v, float a, float b) { return v < a ? a : v > b ? b : v; }
}
