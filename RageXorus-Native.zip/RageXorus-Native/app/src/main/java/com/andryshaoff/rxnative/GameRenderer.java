package com.andryshaoff.rxnative;

import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.SystemClock;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Кадр игры: логика + отрисовка. Весь мир — одна сетка (1 вызов отрисовки), бойцы — простые коробки, бойцы за стенами не рисуются. */
final class GameRenderer implements GLSurfaceView.Renderer {
    static volatile Game game;           // читает HUD
    static volatile float fps;
    static volatile int drawCalls;

    private final World world; private final Game.Events events;
    private final Gfx gfx = new Gfx();
    private Gfx.Mesh worldMesh, cube;
    private final float[] proj = new float[16], view = new float[16], vp = new float[16], m = new float[16], tmp = new float[16], vmProj = new float[16];
    private long last; private float fpsAcc; private int fpsN;
    private int width = 1, height = 1;
    static volatile float sens = 1f; static volatile int fpsCap = 60;

    static final float[] FOG = {0.86f, 0.78f, 0.64f};

    GameRenderer(World w, Game.Events ev) { world = w; events = ev; }

    @Override public void onSurfaceCreated(GL10 unused, EGLConfig config) {
        gfx.init();
        worldMesh = new Gfx.Mesh(buildWorld());
        Gfx.Builder b = new Gfx.Builder(); b.box(-0.5f, -0.5f, -0.5f, 0.5f, 0.5f, 0.5f, 1, 1, 1, 63, 0.85f); cube = new Gfx.Mesh(b.data());
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);
        GLES30.glClearColor(FOG[0], FOG[1], FOG[2], 1f);
        if (game == null) game = new Game(world, events); else game.ev = events;
        last = SystemClock.elapsedRealtimeNanos();
    }

    @Override public void onSurfaceChanged(GL10 unused, int w, int h) {
        width = Math.max(1, w); height = Math.max(1, h); GLES30.glViewport(0, 0, width, height);
        float a = (float) width / height;
        Matrix.perspectiveM(proj, 0, 70f, a, 0.05f, 160f);
        Matrix.perspectiveM(vmProj, 0, 60f, a, 0.01f, 5f);
    }

    @Override public void onDrawFrame(GL10 unused) {
        long now = SystemClock.elapsedRealtimeNanos();
        // ограничение кадров (телефон не греется и не сбрасывает частоту)
        float minDt = fpsCap > 0 ? 1f / fpsCap : 0;
        float dtRaw = (now - last) / 1e9f;
        if (dtRaw < minDt - 0.0015f) { try { Thread.sleep((long) ((minDt - dtRaw) * 1000)); } catch (InterruptedException ignored) { } now = SystemClock.elapsedRealtimeNanos(); dtRaw = (now - last) / 1e9f; }
        last = now; float dt = Math.min(dtRaw, 0.05f);
        fpsAcc += dtRaw; fpsN++; if (fpsAcc >= 0.5f) { fps = fpsN / fpsAcc; fpsAcc = 0; fpsN = 0; }

        Game g = game; g.update(dt, sens); if (g.tracerT > 0) g.tracerT -= dt;
        Game.Actor me = g.me;

        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);
        // камера
        float ex = me.x, ey = me.alive ? me.eye() : me.y + 3.5f, ez = me.z;
        float yaw = me.yaw, pitch = me.alive ? me.pitch : -0.9f;
        if (!me.alive) { ex += (float) Math.sin(yaw) * 2.5f; ez += (float) Math.cos(yaw) * 2.5f; }
        float cp = (float) Math.cos(pitch), fx = -(float) Math.sin(yaw) * cp, fy = (float) Math.sin(pitch), fz = -(float) Math.cos(yaw) * cp;
        Matrix.setLookAtM(view, 0, ex, ey, ez, ex + fx, ey + fy, ez + fz, 0, 1, 0);
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);

        GLES30.glUseProgram(gfx.prog);
        GLES30.glUniformMatrix4fv(gfx.uVP, 1, false, vp, 0);
        GLES30.glUniform3f(gfx.uCam, ex, ey, ez);
        GLES30.glUniform3f(gfx.uSun, 0.42f, 0.8f, 0.43f);
        GLES30.glUniform3f(gfx.uFogCol, FOG[0], FOG[1], FOG[2]);
        GLES30.glUniform2f(gfx.uFog, 45f, 150f);
        int calls = 0;
        // мир
        Matrix.setIdentityM(m, 0); setM(); tint(1, 1, 1); emis(0); worldMesh.draw(); calls++;
        // бойцы (кроме себя), за стенами — не рисуем
        for (Game.Actor a : g.actors) {
            if (a == me) continue;
            if (!a.alive && a.deadT > 2.5f) continue;
            float dx = a.x - ex, dz = a.z - ez; if (dx * fx + dz * fz < -1.5f) continue; // за спиной
            if (!world.los(ex, ey, ez, a.x, a.y + 1.5f, a.z) && !world.los(ex, ey, ez, a.x, a.y + 0.4f, a.z)
                    && !world.los(ex, ey, ez, a.x + 0.6f, a.y + 1f, a.z) && !world.los(ex, ey, ez, a.x - 0.6f, a.y + 1f, a.z)) continue;
            calls += drawSoldier(a);
        }
        // трассер
        if (g.tracerT > 0) { calls += drawTracer(g.lastTracer); }
        // оружие в руках
        if (me.alive) { GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT); calls += drawViewModel(me, dt); }
        drawCalls = calls;
    }

    private void setM() { GLES30.glUniformMatrix4fv(gfx.uM, 1, false, m, 0); }
    private void tint(float r, float g, float b) { GLES30.glUniform3f(gfx.uTint, r, g, b); }
    private void emis(float e) { GLES30.glUniform1f(gfx.uEmis, e); }

    /** Часть тела: коробка в локальных координатах бойца (base уже содержит позицию и поворот). */
    private void part(float[] base, float px, float py, float pz, float rx, float sx, float sy, float sz, float pivotY, float r, float gg, float b) {
        System.arraycopy(base, 0, tmp, 0, 16);
        Matrix.translateM(tmp, 0, px, py, pz);
        if (rx != 0) { Matrix.translateM(tmp, 0, 0, pivotY, 0); Matrix.rotateM(tmp, 0, rx, 1, 0, 0); Matrix.translateM(tmp, 0, 0, -pivotY, 0); }
        Matrix.scaleM(tmp, 0, sx, sy, sz);
        GLES30.glUniformMatrix4fv(gfx.uM, 1, false, tmp, 0); tint(r, gg, b); cube.draw();
    }

    private final float[] base = new float[16];
    private int drawSoldier(Game.Actor a) {
        Matrix.setIdentityM(base, 0); Matrix.translateM(base, 0, a.x, a.y, a.z); Matrix.rotateM(base, 0, (float) Math.toDegrees(a.yaw), 0, 1, 0);
        if (!a.alive) { float k = Math.min(1, a.deadT * 3); Matrix.translateM(base, 0, 0, 0.2f * k, 0); Matrix.rotateM(base, 0, 88 * k, 1, 0, 0); }
        float c = a.crouchK, sw = (float) Math.sin(a.walkPhase) * 32f;
        float[] col = a.color; float fl = a.hitFlash > 0 ? 2.2f : 1f;
        emis(a.hitFlash > 0 ? 0.6f : 0);
        float hip = 0.95f - 0.35f * c;
        part(base, -0.12f, hip - 0.45f, 0, sw, 0.17f, 0.9f, 0.2f, 0.45f, 0.28f * fl, 0.26f * fl, 0.22f * fl);         // ноги
        part(base, 0.12f, hip - 0.45f, 0, -sw, 0.17f, 0.9f, 0.2f, 0.45f, 0.28f * fl, 0.26f * fl, 0.22f * fl);
        part(base, 0, hip + 0.33f, 0, 0, 0.5f, 0.66f, 0.28f, 0, col[0] * fl, col[1] * fl, col[2] * fl);               // корпус
        part(base, 0, hip + 0.35f, -0.02f, 0, 0.52f, 0.46f, 0.32f, 0, 0.2f * fl, 0.2f * fl, 0.19f * fl);              // бронежилет
        part(base, 0, hip + 0.8f, 0, 0, 0.24f, 0.26f, 0.26f, 0, 0.75f * fl, 0.58f * fl, 0.45f * fl);                 // голова
        part(base, 0, hip + 0.9f, 0.01f, 0, 0.27f, 0.12f, 0.29f, 0, 0.14f * fl, 0.14f * fl, 0.15f * fl);             // шлем
        float ap = (float) Math.toDegrees(-a.pitch) * 0.6f;
        part(base, -0.2f, hip + 0.45f, -0.25f, -80 + ap, 0.12f, 0.55f, 0.12f, 0.2f, col[0] * fl, col[1] * fl, col[2] * fl); // руки вперёд (держат оружие)
        part(base, 0.2f, hip + 0.45f, -0.22f, -75 + ap, 0.12f, 0.5f, 0.12f, 0.2f, col[0] * fl, col[1] * fl, col[2] * fl);
        part(base, 0.06f, hip + 0.5f, -0.55f, ap, 0.08f, 0.12f, 0.75f, 0, 0.12f, 0.12f, 0.13f);                     // автомат
        if (a.alive && a.fireCd > 0.06f) { emis(1); part(base, 0.06f, hip + 0.52f, -0.98f, 0, 0.14f, 0.14f, 0.14f, 0, 1f, 0.8f, 0.35f); emis(0); return 10; }
        return 9;
    }

    private int drawTracer(float[] t) {
        float dx = t[3] - t[0], dy = t[4] - t[1], dz = t[5] - t[2], L = (float) Math.sqrt(dx * dx + dy * dy + dz * dz); if (L < 0.5f) return 0;
        Matrix.setIdentityM(tmp, 0); Matrix.translateM(tmp, 0, (t[0] + t[3]) / 2, (t[1] + t[4]) / 2, (t[2] + t[5]) / 2);
        float yaw = (float) Math.toDegrees(Math.atan2(dx, dz)), pit = (float) Math.toDegrees(Math.asin(dy / L));
        Matrix.rotateM(tmp, 0, yaw, 0, 1, 0); Matrix.rotateM(tmp, 0, -pit, 1, 0, 0); Matrix.scaleM(tmp, 0, 0.02f, 0.02f, L);
        GLES30.glUniformMatrix4fv(gfx.uM, 1, false, tmp, 0); emis(1); tint(1f, 0.85f, 0.45f); cube.draw(); emis(0); return 1;
    }

    private float bob;
    private int drawViewModel(Game.Actor me, float dt) {
        GLES30.glUniformMatrix4fv(gfx.uVP, 1, false, vmProj, 0); GLES30.glUniform3f(gfx.uCam, 0, 0, 0);
        bob += dt * ((Math.abs(Input.moveX) + Math.abs(Input.moveY)) > 0.2f ? 9f : 2f);
        float by = (float) Math.sin(bob) * 0.008f, bx = (float) Math.cos(bob * 0.5f) * 0.01f;
        float kick = me.recoil * 0.04f, rel = me.reloadT > 0 ? (float) Math.sin(Math.min(1, (2.3f - me.reloadT) / 2.3f) * Math.PI) : 0;
        Matrix.setIdentityM(base, 0); Matrix.translateM(base, 0, 0.17f + bx, -0.19f + by - rel * 0.12f, -0.42f + kick);
        Matrix.rotateM(base, 0, rel * 35f, 0, 0, 1); Matrix.rotateM(base, 0, 3f, 0, 1, 0);
        emis(0);
        part(base, 0, 0, 0, 0, 0.06f, 0.08f, 0.52f, 0, 0.13f, 0.13f, 0.14f);              // ствольная коробка
        part(base, 0, 0.005f, -0.34f, 0, 0.03f, 0.03f, 0.25f, 0, 0.1f, 0.1f, 0.1f);      // ствол
        part(base, 0, -0.07f, -0.08f, 20f, 0.05f, 0.14f, 0.07f, 0, 0.35f, 0.22f, 0.12f);  // магазин
        part(base, 0, -0.03f, 0.25f, 0, 0.055f, 0.1f, 0.2f, 0, 0.42f, 0.27f, 0.14f);     // приклад
        part(base, 0, 0.01f, -0.16f, 0, 0.065f, 0.06f, 0.16f, 0, 0.42f, 0.27f, 0.14f);   // цевьё
        part(base, -0.05f, -0.07f, -0.16f, -20f, 0.06f, 0.06f, 0.2f, 0, 0.12f, 0.14f, 0.2f); // левая рука
        part(base, 0.02f, -0.08f, 0.08f, 0, 0.06f, 0.06f, 0.18f, 0, 0.12f, 0.14f, 0.2f);  // правая рука
        int n = 7;
        if (me.fireCd > 0.065f) { emis(1); part(base, 0, 0.005f, -0.5f, (float) (Math.random() * 90), 0.06f, 0.06f, 0.06f, 0, 1f, 0.78f, 0.3f); emis(0); n++; }
        return n;
    }

    /* ---------------- геометрия карты ---------------- */
    private float[] buildWorld() {
        Gfx.Builder b = new Gfx.Builder(); World w = world; float C = World.CELL;
        for (int z = 0; z < w.H; z++) for (int x = 0; x < w.W; x++) {
            char ch = w.at(x, z); float t = w.topAt(x, z), x0 = x * C, z0 = z * C, x1 = x0 + C, z1 = z0 + C;
            float v = 0.94f + 0.06f * (((x * 7 + z * 13) % 5) / 4f);
            // пол
            if (ch != '#') {
                float[] fc;
                switch (ch) {
                    case ':': fc = ((x + z) % 2 == 0) ? new float[]{0.76f, 0.69f, 0.58f} : new float[]{0.72f, 0.65f, 0.55f}; break;
                    case ',': fc = new float[]{0.56f, 0.47f, 0.38f}; break;
                    case '_': fc = new float[]{0.58f, 0.43f, 0.29f}; break;
                    case 'A': case 'B': fc = new float[]{0.84f, 0.62f, 0.46f}; break;
                    default: fc = new float[]{0.86f, 0.74f, 0.54f};
                }
                b.box(x0, -0.1f, z0, x1, 0, z1, fc[0] * v, fc[1] * v, fc[2] * v, 1, 1);
            }
            if (t <= 0) continue;
            if (ch == '#') {
                float r = 0.87f * v, g = 0.71f * v, bl = 0.5f * v;
                b.box(x0, 0, z0, x1, t, z1, r * 1.04f, g * 1.04f, bl * 1.04f, 1, 1); // крыша
                // стены — только там, где сосед ниже
                sideIfLower(b, w, x + 1, z, t, x1, z0, x1, z1, 1, 0, r, g, bl);
                sideIfLower(b, w, x - 1, z, t, x0, z1, x0, z0, -1, 0, r, g, bl);
                sideIfLower(b, w, x, z + 1, t, x1, z1, x0, z1, 0, 1, r, g, bl);
                sideIfLower(b, w, x, z - 1, t, x0, z0, x1, z0, 0, -1, r, g, bl);
                // карниз
                if (t < 10) b.box(x0 - 0.05f, t - 0.25f, z0 - 0.05f, x1 + 0.05f, t, z1 + 0.05f, r * 0.9f, g * 0.9f, bl * 0.9f, 60, 1);
            } else {
                float m0 = ch == 'o' ? 0.6f : ch == 'c' ? 0.25f : ch == 'C' ? 0.12f : 0.05f;
                float[] cc = ch == 'c' || ch == 'C' ? new float[]{0.62f, 0.45f, 0.27f} : ch == 'o' ? new float[]{0.45f, 0.3f, 0.2f} : ch == 's' ? new float[]{0.66f, 0.6f, 0.44f} : new float[]{0.7f, 0.64f, 0.55f};
                b.box(x0 + m0, 0, z0 + m0, x1 - m0, t, z1 - m0, cc[0] * v, cc[1] * v, cc[2] * v, 61, 0.7f);
                if (ch == 'c' || ch == 'C') b.box(x0 + m0 - 0.02f, t * 0.45f, z0 + m0 - 0.02f, x1 - m0 + 0.02f, t * 0.55f, z1 - m0 + 0.02f, 0.45f, 0.32f, 0.2f, 60, 1); // рейка
            }
        }
        return b.data();
    }

    private static void sideIfLower(Gfx.Builder b, World w, int nx, int nz, float t, float ax, float az, float bx, float bz, float nX, float nZ, float r, float g, float bl) {
        float nt = Math.min(t, w.topAt(nx, nz)); if (nt >= t) return;
        float k = nX != 0 ? 0.93f : 1f; // разные стороны — немного разный тон
        b.quad(new float[]{ax, nt, az}, new float[]{bx, nt, bz}, new float[]{bx, t, bz}, new float[]{ax, t, az}, nX, 0, nZ, r * k, g * k, bl * k, nt < 0.01f ? 0.72f : 0.9f);
    }
}
