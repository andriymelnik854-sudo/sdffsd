package com.andryshaoff.rxnative;

import android.opengl.GLES30;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

/** Минимальная графика на OpenGL ES 3.0: один шейдер (простой свет + туман), сетки в VAO, сборщик коробок. */
final class Gfx {
    static final String VS = "#version 300 es\n" +
            "layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNor; layout(location=2) in vec3 aCol;\n" +
            "uniform mat4 uVP; uniform mat4 uM; uniform vec3 uTint; uniform vec3 uCam;\n" +
            "out vec3 vCol; out vec3 vNor; out float vDist;\n" +
            "void main(){ vec4 w = uM * vec4(aPos, 1.0); gl_Position = uVP * w; vNor = mat3(uM) * aNor; vCol = aCol * uTint; vDist = length(w.xyz - uCam); }\n";
    static final String FS = "#version 300 es\nprecision mediump float;\n" +
            "in vec3 vCol; in vec3 vNor; in float vDist;\n" +
            "uniform vec3 uSun; uniform vec3 uFogCol; uniform vec2 uFog; uniform float uEmis; out vec4 o;\n" +
            "void main(){ vec3 n = normalize(vNor); float d = max(dot(n, uSun), 0.0); float hemi = 0.46 + 0.2 * n.y;\n" +
            " vec3 c = vCol * (hemi + 0.62 * d); c = mix(c, vCol, uEmis);\n" +
            " float f = clamp((vDist - uFog.x) / (uFog.y - uFog.x), 0.0, 1.0); o = vec4(mix(c, uFogCol, f), 1.0); }\n";

    int prog, uVP, uM, uTint, uCam, uSun, uFogCol, uFog, uEmis;

    void init() {
        int vs = compile(GLES30.GL_VERTEX_SHADER, VS), fs = compile(GLES30.GL_FRAGMENT_SHADER, FS);
        prog = GLES30.glCreateProgram(); GLES30.glAttachShader(prog, vs); GLES30.glAttachShader(prog, fs); GLES30.glLinkProgram(prog);
        int[] ok = new int[1]; GLES30.glGetProgramiv(prog, GLES30.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("link: " + GLES30.glGetProgramInfoLog(prog));
        uVP = GLES30.glGetUniformLocation(prog, "uVP"); uM = GLES30.glGetUniformLocation(prog, "uM"); uTint = GLES30.glGetUniformLocation(prog, "uTint");
        uCam = GLES30.glGetUniformLocation(prog, "uCam"); uSun = GLES30.glGetUniformLocation(prog, "uSun"); uFogCol = GLES30.glGetUniformLocation(prog, "uFogCol");
        uFog = GLES30.glGetUniformLocation(prog, "uFog"); uEmis = GLES30.glGetUniformLocation(prog, "uEmis");
    }

    private static int compile(int type, String src) {
        int s = GLES30.glCreateShader(type); GLES30.glShaderSource(s, src); GLES30.glCompileShader(s);
        int[] ok = new int[1]; GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("shader: " + GLES30.glGetShaderInfoLog(s));
        return s;
    }

    /** Сетка: позиция, нормаль, цвет (9 float на вершину). */
    static final class Mesh {
        int vao, vbo, count;
        Mesh(float[] data) {
            count = data.length / 9;
            FloatBuffer fb = ByteBuffer.allocateDirect(data.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer(); fb.put(data).position(0);
            int[] id = new int[1];
            GLES30.glGenVertexArrays(1, id, 0); vao = id[0]; GLES30.glBindVertexArray(vao);
            GLES30.glGenBuffers(1, id, 0); vbo = id[0]; GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, data.length * 4, fb, GLES30.GL_STATIC_DRAW);
            for (int i = 0; i < 3; i++) { GLES30.glEnableVertexAttribArray(i); GLES30.glVertexAttribPointer(i, 3, GLES30.GL_FLOAT, false, 36, i * 12); }
            GLES30.glBindVertexArray(0);
        }
        void draw() { GLES30.glBindVertexArray(vao); GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, count); }
    }

    /** Сборщик геометрии из коробок и прямоугольников. */
    static final class Builder {
        float[] d = new float[9 * 4096]; int n;
        private void v(float x, float y, float z, float nx, float ny, float nz, float r, float g, float b) {
            if (n + 9 > d.length) d = java.util.Arrays.copyOf(d, d.length * 2);
            d[n++] = x; d[n++] = y; d[n++] = z; d[n++] = nx; d[n++] = ny; d[n++] = nz; d[n++] = r; d[n++] = g; d[n++] = b;
        }
        /** Четырёхугольник a-b-c-d (против часовой при взгляде снаружи). */
        void quad(float[] a, float[] b, float[] c, float[] e, float nx, float ny, float nz, float r, float g, float bl, float shadeBottom) {
            float k = shadeBottom; // низ чуть темнее — дешёвая имитация затенения у земли
            v(a[0], a[1], a[2], nx, ny, nz, r * k, g * k, bl * k); v(b[0], b[1], b[2], nx, ny, nz, r * k, g * k, bl * k); v(c[0], c[1], c[2], nx, ny, nz, r, g, bl);
            v(a[0], a[1], a[2], nx, ny, nz, r * k, g * k, bl * k); v(c[0], c[1], c[2], nx, ny, nz, r, g, bl); v(e[0], e[1], e[2], nx, ny, nz, r, g, bl);
        }
        /** Коробка; mask — какие грани рисовать: 1 верх, 2 низ, 4 +x, 8 -x, 16 +z, 32 -z. */
        void box(float x0, float y0, float z0, float x1, float y1, float z1, float r, float g, float b, int mask, float ao) {
            if ((mask & 1) != 0) quad(new float[]{x0, y1, z1}, new float[]{x1, y1, z1}, new float[]{x1, y1, z0}, new float[]{x0, y1, z0}, 0, 1, 0, r, g, b, 1f);
            if ((mask & 2) != 0) quad(new float[]{x0, y0, z0}, new float[]{x1, y0, z0}, new float[]{x1, y0, z1}, new float[]{x0, y0, z1}, 0, -1, 0, r, g, b, 1f);
            if ((mask & 4) != 0) quad(new float[]{x1, y0, z1}, new float[]{x1, y0, z0}, new float[]{x1, y1, z0}, new float[]{x1, y1, z1}, 1, 0, 0, r, g, b, ao);
            if ((mask & 8) != 0) quad(new float[]{x0, y0, z0}, new float[]{x0, y0, z1}, new float[]{x0, y1, z1}, new float[]{x0, y1, z0}, -1, 0, 0, r, g, b, ao);
            if ((mask & 16) != 0) quad(new float[]{x0, y0, z1}, new float[]{x1, y0, z1}, new float[]{x1, y1, z1}, new float[]{x0, y1, z1}, 0, 0, 1, r, g, b, ao);
            if ((mask & 32) != 0) quad(new float[]{x1, y0, z0}, new float[]{x0, y0, z0}, new float[]{x0, y1, z0}, new float[]{x1, y1, z0}, 0, 0, -1, r, g, b, ao);
        }
        float[] data() { return java.util.Arrays.copyOf(d, n); }
    }
}
