package com.andryshaoff.rxnative;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/** Сенсорное управление и HUD поверх 3D (рисуется 30 раз в секунду обычным Canvas). */
final class Hud extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), stroke = new Paint(Paint.ANTI_ALIAS_FLAG), text = new Paint(Paint.ANTI_ALIAS_FLAG);
    // кнопки: x, y (доли экрана), радиус (доля высоты)
    private static final float[][] BTN = {{0.87f, 0.62f, 0.10f}, {0.08f, 0.45f, 0.065f}, {0.94f, 0.38f, 0.06f}, {0.95f, 0.76f, 0.06f}, {0.79f, 0.88f, 0.055f}, {0.3f, 0.78f, 0.045f}};
    private static final String[] LBL = {"ОГОНЬ", "ОГОНЬ", "▲", "▼", "R", "ШАГ"};
    private static final int FIRE = 0, FIRE2 = 1, JUMP = 2, CROUCH = 3, RELOAD = 4, WALK = 5;
    private final int[] owner = new int[6];          // какой палец держит кнопку (-1 — никто)
    private int joyId = -1; private float joyCx, joyCy, joyX, joyY;
    private final android.util.SparseArray<float[]> look = new android.util.SparseArray<>();
    private boolean crouchT, walkT;

    Hud(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE); stroke.setColor(Color.argb(170, 255, 255, 255));
        text.setColor(Color.WHITE); text.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD)); text.setShadowLayer(3, 0, 1, Color.BLACK);
        java.util.Arrays.fill(owner, -1);
    }

    private float bx(int i) { return BTN[i][0] * getWidth(); }
    private float by(int i) { return BTN[i][1] * getHeight(); }
    private float br(int i) { return BTN[i][2] * getHeight() * (i == FIRE ? 1f : 1f); }

    private int buttonAt(float x, float y) {
        for (int i = 0; i < BTN.length; i++) { float dx = x - bx(i), dy = y - by(i), r = br(i) * 1.25f; if (dx * dx + dy * dy < r * r) return i; }
        return -1;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            int i = e.getActionIndex(); int id = e.getPointerId(i); float x = e.getX(i), y = e.getY(i);
            Game g = GameRenderer.game; if (g != null && !g.me.alive) return true;
            int b = buttonAt(x, y);
            if (b >= 0) {
                owner[b] = id;
                if (b == FIRE || b == FIRE2) { Input.fire = true; look.put(id, new float[]{x, y}); }
                else if (b == JUMP) Input.jumpQ = true;
                else if (b == RELOAD) Input.reloadQ = true;
                else if (b == CROUCH) { crouchT = !Input.crouch; Input.crouch = crouchT; }
                else if (b == WALK) { walkT = !Input.walk; Input.walk = walkT; }
            } else if (x < getWidth() * 0.4f && joyId < 0) { joyId = id; joyCx = x; joyCy = y; joyX = x; joyY = y; }
            else look.put(id, new float[]{x, y});
        } else if (act == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                int id = e.getPointerId(i); float x = e.getX(i), y = e.getY(i);
                if (id == joyId) { joyX = x; joyY = y; float R = getHeight() * 0.13f, dx = (x - joyCx) / R, dy = (y - joyCy) / R, L = (float) Math.sqrt(dx * dx + dy * dy); if (L > 1) { dx /= L; dy /= L; } Input.moveX = dx; Input.moveY = dy; }
                float[] p = look.get(id);
                if (p != null) { Input.addLook(x - p[0], y - p[1]); p[0] = x; p[1] = y; }
            }
        } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_POINTER_UP || act == MotionEvent.ACTION_CANCEL) {
            int n = act == MotionEvent.ACTION_CANCEL ? e.getPointerCount() : 1;
            for (int k = 0; k < n; k++) {
                int i = act == MotionEvent.ACTION_CANCEL ? k : e.getActionIndex(); int id = e.getPointerId(i);
                if (id == joyId) { joyId = -1; Input.moveX = Input.moveY = 0; }
                look.remove(id);
                for (int b = 0; b < owner.length; b++) if (owner[b] == id) owner[b] = -1;
                Input.fire = owner[FIRE] >= 0 || owner[FIRE2] >= 0;
            }
        }
        return true;
    }

    @Override protected void onDraw(Canvas c) {
        int W = getWidth(), H = getHeight(); Game g = GameRenderer.game;
        float u = H / 100f;
        // кнопки
        for (int i = 0; i < BTN.length; i++) {
            boolean on = owner[i] >= 0 || (i == CROUCH && Input.crouch) || (i == WALK && Input.walk);
            fill.setColor(on ? Color.argb(110, 255, 255, 255) : Color.argb(70, 10, 14, 18)); c.drawCircle(bx(i), by(i), br(i), fill);
            stroke.setStrokeWidth(u * 0.3f); c.drawCircle(bx(i), by(i), br(i), stroke);
            text.setTextSize(LBL[i].length() > 2 ? u * 2.4f : u * 4f); text.setTextAlign(Paint.Align.CENTER);
            c.drawText(LBL[i], bx(i), by(i) + text.getTextSize() * 0.35f, text);
        }
        // джойстик
        float jx = joyId >= 0 ? joyCx : W * 0.15f, jy = joyId >= 0 ? joyCy : H * 0.72f, R = H * 0.13f;
        fill.setColor(Color.argb(60, 10, 14, 18)); c.drawCircle(jx, jy, R, fill); stroke.setStrokeWidth(u * 0.3f); c.drawCircle(jx, jy, R, stroke);
        float kx = joyId >= 0 ? jx + Input.moveX * R : jx, ky = joyId >= 0 ? jy + Input.moveY * R : jy;
        fill.setColor(Color.argb(120, 255, 255, 255)); c.drawCircle(kx, ky, R * 0.4f, fill);
        if (g != null) {
            Game.Actor me = g.me;
            // прицел + отметка попадания
            float cx = W / 2f, cy = H / 2f, gap = u * (1.2f + me.spread * 40 + me.recoil * 2);
            stroke.setColor(Color.argb(230, 150, 255, 180)); stroke.setStrokeWidth(u * 0.35f);
            c.drawLine(cx - gap - u * 2, cy, cx - gap, cy, stroke); c.drawLine(cx + gap, cy, cx + gap + u * 2, cy, stroke);
            c.drawLine(cx, cy - gap - u * 2, cx, cy - gap, stroke); c.drawLine(cx, cy + gap, cx, cy + gap + u * 2, stroke);
            if (g.time - g.hudHitT < 0.15f) { stroke.setColor(Color.WHITE); float a = u * 1.5f, b = u * 3f; c.drawLine(cx - b, cy - b, cx - a, cy - a, stroke); c.drawLine(cx + b, cy - b, cx + a, cy - a, stroke); c.drawLine(cx - b, cy + b, cx - a, cy + a, stroke); c.drawLine(cx + b, cy + b, cx + a, cy + a, stroke); }
            stroke.setColor(Color.argb(170, 255, 255, 255));
            if (g.time - g.hudHurtT < 0.3f) { fill.setColor(Color.argb((int) (120 * (1 - (g.time - g.hudHurtT) / 0.3f)), 200, 20, 40)); c.drawRect(0, 0, W, H, fill); }
            // здоровье, патроны
            text.setTextAlign(Paint.Align.LEFT); text.setTextSize(u * 7f); text.setColor(me.hp < 30 ? Color.rgb(255, 90, 110) : Color.WHITE);
            c.drawText("+" + (int) me.hp, W * 0.25f, H - u * 3, text);
            text.setTextAlign(Paint.Align.RIGHT); text.setColor(Color.WHITE);
            c.drawText(me.reloadT > 0 ? "..." : String.valueOf(me.mag), W * 0.66f, H - u * 3, text);
            text.setTextSize(u * 3.5f); text.setTextAlign(Paint.Align.LEFT); c.drawText("/ " + me.reserve, W * 0.665f, H - u * 3, text);
            // счёт, FPS
            text.setTextAlign(Paint.Align.CENTER); text.setTextSize(u * 4f);
            c.drawText("УБИЙСТВ " + me.kills + "  ·  СМЕРТЕЙ " + me.deaths, W / 2f, u * 6, text);
            text.setTextSize(u * 2.6f); text.setTextAlign(Paint.Align.LEFT); text.setColor(Color.rgb(140, 255, 200));
            c.drawText("FPS " + Math.round(GameRenderer.fps) + "  ·  вызовов " + GameRenderer.drawCalls, u * 2, u * 4, text);
            text.setColor(Color.WHITE);
            if (g.time - g.lastKillT < 4) { text.setTextAlign(Paint.Align.RIGHT); text.setTextSize(u * 3f); c.drawText(g.lastKill, W - u * 2, u * 12, text); }
            if (!me.alive) { text.setTextAlign(Paint.Align.CENTER); text.setTextSize(u * 8f); text.setColor(Color.rgb(255, 90, 110)); c.drawText("ВАС УБИЛИ", W / 2f, H * 0.4f, text);
                text.setTextSize(u * 4f); text.setColor(Color.WHITE); c.drawText("возрождение через " + Math.max(0, Math.round(me.respawnT * 10) / 10f) + " с", W / 2f, H * 0.4f + u * 7, text); }
        }
        postInvalidateDelayed(33);
    }
}
