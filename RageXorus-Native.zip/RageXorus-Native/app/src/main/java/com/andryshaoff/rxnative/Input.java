package com.andryshaoff.rxnative;

/** Состояние сенсорного управления: пишет экран (поток интерфейса), читает игра (поток OpenGL). */
final class Input {
    static volatile float moveX, moveY;          // джойстик: -1..1 (moveY < 0 — вперёд)
    static volatile boolean fire, crouch, walk, aim;
    static volatile boolean jumpQ, reloadQ;      // одноразовые нажатия
    private static float lookX, lookY;

    static synchronized void addLook(float dx, float dy) { lookX += dx; lookY += dy; }
    static synchronized void takeLook(float[] out) { out[0] = lookX; out[1] = lookY; lookX = 0; lookY = 0; }
    static void reset() { moveX = moveY = 0; fire = crouch = walk = aim = jumpQ = reloadQ = false; synchronized (Input.class) { lookX = lookY = 0; } }
}
