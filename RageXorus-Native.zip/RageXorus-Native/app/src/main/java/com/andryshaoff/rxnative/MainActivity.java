package com.andryshaoff.rxnative;

import android.app.Activity;
import android.content.res.AssetManager;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** RageXorus Native — прототип на Java + OpenGL ES 3.0 (без браузера внутри). */
public class MainActivity extends Activity {
    private GLSurfaceView gl; private Sfx sfx;
    static final float RENDER_SCALE = 0.8f; // 3D рисуется в 80% разрешения экрана и растягивается видеочипом бесплатно

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 28) getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;

        World world = new World(readAsset(getAssets(), "dune.txt"));
        sfx = new Sfx(this); Input.reset();
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setPreserveEGLContextOnPause(true);
        gl.setRenderer(new GameRenderer(world, sfx));
        gl.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override public void surfaceCreated(SurfaceHolder h) { if (Build.VERSION.SDK_INT >= 30) { try { h.getSurface().setFrameRate(60f, 0); } catch (Exception ignored) { } } }
            @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) { }
            @Override public void surfaceDestroyed(SurfaceHolder h) { }
        });
        gl.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            int w = r - l, h = b - t; if (w <= 0 || h <= 0) return;
            int fw = Math.round(w * RENDER_SCALE), fh = Math.round(h * RENDER_SCALE);
            if (fw != lastFw || fh != lastFh) { lastFw = fw; lastFh = fh; gl.getHolder().setFixedSize(fw, fh); }
        });

        FrameLayout root = new FrameLayout(this);
        root.addView(gl, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(new Hud(this), new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        immersive();
    }
    private int lastFw, lastFh;

    @SuppressWarnings("deprecation")
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) immersive(); }
    @Override protected void onPause() { super.onPause(); gl.onPause(); Input.reset(); }
    @Override protected void onResume() { super.onResume(); gl.onResume(); immersive(); }
    @Override protected void onDestroy() { super.onDestroy(); if (sfx != null) sfx.release(); }

    static String readAsset(AssetManager am, String name) {
        try (InputStream in = am.open(name)) { ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); return o.toString("UTF-8"); }
        catch (Exception e) { throw new RuntimeException(e); }
    }
}
