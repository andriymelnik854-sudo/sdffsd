package com.andryshaoff.rxnative;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Random;

/** Звуки синтезируются при запуске в WAV-файлы и играются через SoundPool (низкая задержка, смешивание делает система). */
final class Sfx implements Game.Events {
    private final SoundPool pool; private final int shot, farShot, hit, head, hurt;

    Sfx(Context c) {
        pool = new SoundPool.Builder().setMaxStreams(10).setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build();
        shot = load(c, "shot", gun(0.22f, 1f, 1)); farShot = load(c, "far", gun(0.35f, 0.35f, 2));
        hit = load(c, "hit", tone(1800, 0.05f, 0.5f)); head = load(c, "head", tone(2600, 0.08f, 0.6f)); hurt = load(c, "hurt", gun(0.12f, 0.6f, 3));
    }

    private int load(Context c, String name, short[] pcm) {
        try { File f = new File(c.getCacheDir(), name + ".wav"); try (FileOutputStream o = new FileOutputStream(f)) { o.write(wav(pcm)); } return pool.load(f.getPath(), 1); }
        catch (Exception e) { return 0; }
    }

    private static short[] gun(float len, float amp, int seed) {
        int sr = 22050, n = (int) (sr * len); short[] s = new short[n]; Random r = new Random(seed); float lp = 0;
        for (int i = 0; i < n; i++) { float t = i / (float) sr, env = (float) Math.exp(-t * 18) + 0.25f * (float) Math.exp(-t * 5);
            float noise = r.nextFloat() * 2 - 1; lp += (noise - lp) * (0.35f + 0.4f * (float) Math.exp(-t * 30));
            float thump = (float) Math.sin(2 * Math.PI * 90 * t) * (float) Math.exp(-t * 25);
            s[i] = (short) (Math.max(-1, Math.min(1, (lp * 0.9f + thump * 0.6f) * env * amp)) * 32000); }
        return s;
    }

    private static short[] tone(float hz, float len, float amp) {
        int sr = 22050, n = (int) (sr * len); short[] s = new short[n];
        for (int i = 0; i < n; i++) { float t = i / (float) sr; s[i] = (short) (Math.sin(2 * Math.PI * hz * t) * Math.exp(-t * 40) * amp * 32000); }
        return s;
    }

    private static byte[] wav(short[] pcm) {
        int sr = 22050, len = pcm.length * 2; byte[] b = new byte[44 + len];
        java.nio.ByteBuffer bb = java.nio.ByteBuffer.wrap(b).order(java.nio.ByteOrder.LITTLE_ENDIAN);
        bb.put("RIFF".getBytes()).putInt(36 + len).put("WAVE".getBytes()).put("fmt ".getBytes()).putInt(16).putShort((short) 1).putShort((short) 1)
                .putInt(sr).putInt(sr * 2).putShort((short) 2).putShort((short) 16).put("data".getBytes()).putInt(len);
        for (short v : pcm) bb.putShort(v);
        return b;
    }

    @Override public void shot(boolean me, float dist) {
        if (me) pool.play(shot, 0.8f, 0.8f, 1, 0, 1f);
        else { float v = Math.max(0.05f, Math.min(0.7f, 12f / (dist + 6))); pool.play(dist > 25 ? farShot : shot, v, v, 0, 0, 0.9f + (float) Math.random() * 0.15f); }
    }
    @Override public void hitMarker(boolean h) { pool.play(h ? head : hit, 0.6f, 0.6f, 2, 0, 1f); }
    @Override public void hurt() { pool.play(hurt, 0.7f, 0.7f, 2, 0, 0.7f); }
    @Override public void kill(String k, String v, boolean h) { }
    void release() { pool.release(); }
}
