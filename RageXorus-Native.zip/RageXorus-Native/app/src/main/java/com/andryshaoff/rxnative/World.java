package com.andryshaoff.rxnative;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.PriorityQueue;

/** Карта в клетках 2×2 м (тот же формат, что и в HTML-версии): высоты, столкновения, лучи, поиск пути. */
final class World {
    static final float CELL = 2f;
    final int W, H;
    final char[][] g;
    final float[] top;          // высота препятствия в клетке (0 — пол)
    final List<int[]> spawns = new ArrayList<>();

    World(String txt) {
        String[] rows = txt.replace("\r", "").trim().split("\n");
        H = rows.length; int w = 0; for (String r : rows) w = Math.max(w, r.length()); W = w;
        g = new char[H][W]; top = new float[W * H];
        for (int z = 0; z < H; z++) for (int x = 0; x < W; x++) {
            char c = x < rows[z].length() ? rows[z].charAt(x) : '#';
            g[z][x] = c; top[z * W + x] = heightOf(c, x, z);
            if (c == 'T' || c == 'K') spawns.add(new int[]{x, z});
        }
    }

    private float heightOf(char c, int x, int z) {
        switch (c) {
            case '#': {
                boolean edge = x == 0 || z == 0 || x == W - 1 || z == H - 1;
                if (edge) return 11f;
                int h = ((x / 3) * 73856093) ^ ((z / 3) * 19349663); h = (h >>> 7) % 5;
                return new float[]{5.2f, 6.4f, 7.2f, 8.4f, 9.6f}[Math.abs(h)];
            }
            case 'C': return 2.2f;
            case 'c': return 1.1f;
            case '=': return 1.0f;
            case 's': return 0.9f;
            case 'o': return 1.05f;
            default: return 0f;
        }
    }

    float topAt(int x, int z) { return (x < 0 || z < 0 || x >= W || z >= H) ? 20f : top[z * W + x]; }
    char at(int x, int z) { return (x < 0 || z < 0 || x >= W || z >= H) ? '#' : g[z][x]; }
    boolean walkable(int x, int z) { return topAt(x, z) < 0.3f; }
    static int cellOf(float v) { return (int) Math.floor(v / CELL); }

    /** Самая высокая опора под кругом радиуса r, на которую можно встать (не выше ног + ступенька). */
    float groundAt(float x, float z, float r, float feet) {
        float best = 0f;
        int x0 = cellOf(x - r), x1 = cellOf(x + r), z0 = cellOf(z - r), z1 = cellOf(z + r);
        for (int cz = z0; cz <= z1; cz++) for (int cx = x0; cx <= x1; cx++) {
            float t = topAt(cx, cz); if (t <= feet + 0.45f && t > best) best = t;
        }
        return best;
    }

    /** Мешает ли что-то кругу (x,z,r) на высоте ног feet. */
    boolean blocked(float x, float z, float r, float feet) {
        int x0 = cellOf(x - r), x1 = cellOf(x + r), z0 = cellOf(z - r), z1 = cellOf(z + r);
        for (int cz = z0; cz <= z1; cz++) for (int cx = x0; cx <= x1; cx++) {
            float t = topAt(cx, cz); if (t <= feet + 0.45f) continue;
            // точная проверка круг ↔ квадрат клетки
            float nx = Math.max(cx * CELL, Math.min(x, (cx + 1) * CELL)), nz = Math.max(cz * CELL, Math.min(z, (cz + 1) * CELL));
            float dx = x - nx, dz = z - nz; if (dx * dx + dz * dz < r * r) return true;
        }
        return false;
    }

    /** Расстояние до первой преграды по лучу (dir — единичный вектор). */
    float ray(float ox, float oy, float oz, float dx, float dy, float dz, float max) {
        if (dy < 0) { float tf = -oy / dy; if (tf < max) max = tf; } // пол
        float hl = (float) Math.sqrt(dx * dx + dz * dz);
        int cx = cellOf(ox), cz = cellOf(oz);
        if (hl < 1e-5f) { float t = topAt(cx, cz); return oy < t ? 0 : max; }
        int sx = dx > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
        float tdx = dx != 0 ? Math.abs(CELL / dx) : Float.MAX_VALUE, tdz = dz != 0 ? Math.abs(CELL / dz) : Float.MAX_VALUE;
        float tx = dx != 0 ? ((sx > 0 ? (cx + 1) * CELL - ox : ox - cx * CELL) / Math.abs(dx)) : Float.MAX_VALUE;
        float tz = dz != 0 ? ((sz > 0 ? (cz + 1) * CELL - oz : oz - cz * CELL) / Math.abs(dz)) : Float.MAX_VALUE;
        float t0 = 0;
        for (int i = 0; i < 512; i++) {
            float t1 = Math.min(Math.min(tx, tz), max);
            float top = topAt(cx, cz);
            if (top > 0) {
                float y0 = oy + dy * t0, y1 = oy + dy * t1;
                if (y0 < top) return t0;
                if (y1 < top) return t0 + (top - y0) / (y1 - y0) * (t1 - t0);
            }
            if (t1 >= max) return max;
            t0 = t1;
            if (tx < tz) { cx += sx; tx += tdx; } else { cz += sz; tz += tdz; }
        }
        return max;
    }

    /** Прямая видимость между точками. */
    boolean los(float ax, float ay, float az, float bx, float by, float bz) {
        float dx = bx - ax, dy = by - ay, dz = bz - az, d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d < 0.01f) return true;
        return ray(ax, ay, az, dx / d, dy / d, dz / d, d) >= d - 0.05f;
    }

    /** A* по проходимым клеткам (8 направлений, без срезания углов). Возвращает клетки от старта к цели. */
    int[] path(int sx, int sz, int tx, int tz) {
        if (!walkable(tx, tz) || !walkable(sx, sz)) return null;
        int N = W * H; float[] gs = new float[N]; Arrays.fill(gs, Float.MAX_VALUE); int[] from = new int[N]; Arrays.fill(from, -1);
        boolean[] closed = new boolean[N];
        PriorityQueue<float[]> open = new PriorityQueue<>((a, b) -> Float.compare(a[0], b[0]));
        int s = sz * W + sx, t = tz * W + tx; gs[s] = 0; open.add(new float[]{0, s});
        int[][] D = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
        while (!open.isEmpty()) {
            int c = (int) open.poll()[1]; if (closed[c]) continue; closed[c] = true;
            if (c == t) break;
            int cx = c % W, cz = c / W;
            for (int[] d : D) {
                int nx = cx + d[0], nz = cz + d[1]; if (!walkable(nx, nz)) continue;
                if (d[0] != 0 && d[1] != 0 && (!walkable(cx + d[0], cz) || !walkable(cx, cz + d[1]))) continue;
                int n = nz * W + nx; float ng = gs[c] + (d[0] != 0 && d[1] != 0 ? 1.414f : 1f);
                if (ng < gs[n]) { gs[n] = ng; from[n] = c; float h = Math.abs(nx - tx) + Math.abs(nz - tz); open.add(new float[]{ng + h, n}); }
            }
        }
        if (from[t] < 0 && s != t) return null;
        int len = 1; for (int c = t; c != s; c = from[c]) len++;
        int[] out = new int[len]; int i = len - 1; for (int c = t; ; c = from[c]) { out[i--] = c; if (c == s) break; }
        return out;
    }

    int[] randomWalkable(java.util.Random rnd) {
        for (int k = 0; k < 400; k++) { int x = rnd.nextInt(W), z = rnd.nextInt(H); if (walkable(x, z)) return new int[]{x, z}; }
        return spawns.get(0);
    }
}
